const str = ['When it rains i pour', 'JACK', 'til i hit the bottom', 'talking til that bottle tail back'];
const timeOut = [2500, 1400, 2400, 3500];

const song = {
	str: ['When it rains i pour', 'JACK', 'til i hit the bottom', 'talking til that bottle tail back'],
	timeOut: [2500, 1400, 2400, 3500],
};
const lang = {
	str: [
		'Nếu biết trước rằng sẽ mãi xa nhau ',
		'...',
		'Nếu biết trước rằng sẽ mang thương đau ngày sau',
		'...',
		'Sao không níu lấy',
		'...',
		'đôi tay ... thật lâu',
		'...',
		'Để lời yêu thương nhạt màu',
		'Nếu biết trước đường đời rẽ ngang đôi ta ...',
		'...',
		'Nếu biết trước lời hẹn ước sẽ ...',
		'trôi xa ... đi mất',
	],
	timeOut: [3100, 900, 4400, 400, 1800, 700, 1800, 1000, 3200, 3100, 800, 2200, 2400],
};
const wait = ms => {
	return new Promise(resolve => setTimeout(resolve, ms));
};
const prinLyrics = (string, time) => {
	return new Promise(resolve => {
		let index = 0;
		const avgSpeed = Math.floor(time / string.length);
		const interval = setInterval(() => {
			if (index < string.length) {
				process.stdout.write(string[index]);
				index++;
			} else {
				resolve();
				clearInterval(interval);
				console.log();
			}
		}, avgSpeed);
	});
};

const demo = async song => {
	for (let index = 0; index < song.timeOut.length; index++) {
		let time = song.timeOut[index];
		await prinLyrics(song.str[index], time);
	}
};
demo(lang);
